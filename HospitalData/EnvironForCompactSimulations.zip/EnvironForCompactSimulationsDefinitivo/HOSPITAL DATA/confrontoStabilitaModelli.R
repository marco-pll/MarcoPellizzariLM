####### CONFRONTO STABILITA' MODELLI #######

rm(list=ls())

##F1##
max_t0 <- 100
max_dt <- 503
days_selected <- seq(365,365+max_t0, by = 5)

## F2 ##
max_t0 <- 100
max_dt <- 503
days_selected <- seq(365,365+max_t0, by = 5)

## F3 ##
max_t0 <- 60
max_dt <- 202
days_selected <- seq(365,365+max_t0, by = 2)

## F4 ##
max_t0 <- 60
max_dt <- 134
days_selected <- seq(365,365+max_t0, by = 2)

setwd(paste0("C:/Users/User/Documents/AI AGING/SimulationsMachine/",
             "EnvironForCompactSimulations/HOSPITAL DATA/F4_sim_out"))
load(file = "models/models.ridge")
load(file = "results/results.ridge")
load(file = "models/models.rf")
load(file = "results/results.rf")
load(file = "models/models.gb")
load(file = "results/results.gb")
load(file = "models/models.nn")
load(file = "results/results.nn")

## LIVELLI DEI QUANTILI ##
quantLines <- function(models.attr, results) {
  
  res.for.plot <- as.data.frame(t(results))
  res.for.plot$dt <- as.numeric(gsub("dt: ","",rownames(res.for.plot)))
  rownames(res.for.plot) <- NULL
  
  ## Togliamo 
  res.scale.for.plot <- res.for.plot
  
  ## Dividiamo gli MSE assoluti per renderli relativi.
  for (i in 1:nrow(models.attr)) {
    res.scale.for.plot[,i] <- res.scale.for.plot[,i]/as.numeric(models.attr$`MSE a t0`[i])   ## Dividiamo per MSE a t0
  }
  
  ## Calcoliamo i quantili
  qt <- matrix(NA, nrow = max_dt, ncol = 4)
  colnames(qt) <- c("q25","q50","q75","dt")
  rownames(qt) <- 1:max_dt
  
  ## Popoliamo la matrice con i quantili
  for (i in 1:max_dt) {
    qt[i,] <- c(quantile(as.numeric(res.scale.for.plot[i,-ncol(res.scale.for.plot)]), probs = c(0.25,0.5,0.75)),i)
  }
  return(as.data.frame(qt))
}

qtRidge <- quantLines(models.attr.ridge, results.ridge)
qtRF <- quantLines(models.attr.rf, results.rf)
qtGB <- quantLines(models.attr.gb, results.gb)
qtNN <- quantLines(models.attr.nn, results.nn)

#Livelli quantili.
qtLevels <- data.frame(modelli = c("Ridge","RF","GB","NN"),
                       qt50 = round(c(mean(qtRidge$q50),
                                      mean(qtRF$q50),
                                      mean(qtGB$q50),
                                      mean(qtNN$q50)),4),
                       qt75 = round(c(mean(qtRidge$q75),
                                      mean(qtRF$q75),
                                      mean(qtGB$q75),
                                      mean(qtNN$q75)),4))

qtLevelsPerc <- data.frame(modelli = c("Ridge","RF","GB","NN"),
                       qt50 = c(round((mean(qtRidge$q50) - 1)*100,2),
                                      round((mean(qtRF$q50) - 1)*100,2),
                                      round((mean(qtGB$q50) - 1)*100,2),
                                      round((mean(qtNN$q50) - 1)*100,2)),
                       qt75 = c(round((mean(qtRidge$q75) - 1)*100,2),
                                round((mean(qtRF$q75) - 1)*100,2),
                                round((mean(qtGB$q75) - 1)*100,2),
                                round((mean(qtNN$q75) - 1)*100,2)))

#MSE medio iniziale
MSEinit <- data.frame(modelli = c("Ridge","RF","GB","NN"),
                      MSE = c(mean(models.attr.ridge$`MSE a t0`),
                              mean(models.attr.rf$`MSE a t0`),
                              mean(models.attr.gb$`MSE a t0`),
                              mean(models.attr.nn$`MSE a t0`)))

MSEinit$MSE * qtLevels$qt50
MSEinit$MSE * qtLevels$qt75

#Inclinazione mediana.
varErel <- data.frame(modelli = c("Ridge","RF","GB","NN"),
                      varErel = round(c(lm(q50~dt, data = qtRidge)$coefficients["dt"]*max_dt,
                                  lm(q50~dt, data = qtRF)$coefficients["dt"]*max_dt,
                                  lm(q50~dt, data = qtGB)$coefficients["dt"]*max_dt,
                                  lm(q50~dt, data = qtNN)$coefficients["dt"]*max_dt),2))

varErel

## Plot inclinazione mediana.

plot(q50~dt, data = qtRidge, type="l")
beta <- lm(q50~dt, data = qtRidge)$coefficients
names(beta) <- c("int","incl")
degradazione <- beta[1] + beta[2]*c(1:max_dt)

lines(degradazione ~ c(1:max_dt), col="red")


plot(q50~dt, data = qtNN, type="l")
beta <- lm(q50~dt, data = qtNN)$coefficients
names(beta) <- c("int","incl")
degradazione <- beta[1] + beta[2]*c(1:max_dt)

lines(degradazione ~ c(1:max_dt), col="red")



## MSE iniziale medio.
qtLevels

#Caso mediano
mean(models.attr.ridge$`MSE a t0`) * 1.36
mean(models.attr.rf$`MSE a t0`) * 1.34
mean(models.attr.gb$`MSE a t0`) * 1.31

#Caso peggiore
mean(models.attr.ridge$`MSE a t0`) * 0.81
mean(models.attr.nn$`MSE a t0`) * 0.85


      