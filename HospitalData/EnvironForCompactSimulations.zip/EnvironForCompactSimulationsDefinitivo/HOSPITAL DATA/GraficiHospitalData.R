##### PLOT ANALISI PRELIMINARI #####
library(ggplot2)
library(patchwork)
library(RColorBrewer)
setwd(paste0("C:/Users/User/Documents/AI AGING/SimulationsMachine/",
"EnvironForCompactSimulations/HOSPITAL DATA"))

#R2 COMPLESSIVO#

theme_title_r2 <- theme(
  plot.title = element_text(
    hjust = 0.5,  # Center the title
    size = 20,    # Set the font size
    color = "black",  # Set the font color
    family = "serif",
    face ="italic",
    margin = margin(b = 10)  # Add margin at the bottom
  ))

theme_legend_r2 <- theme(legend.position = c(0.5, 0.90), legend.title = element_blank(),
                         panel.border = element_rect(colour = "black", fill=NA),
                         legend.box.margin = margin(t = 1, l = 1,b =1.5,r=1),
                         legend.box.background = element_rect(colour = "black"),
                         legend.direction = "horizontal", legend.key.width = unit(0.5,"cm"),
                         legend.text = element_text(family ="serif", size =15))

theme_axis_r2 <- theme(
  axis.title.x = element_text(size = 18, family = "serif"),
  axis.text.x = element_text(size = 14,family = "serif"),
  axis.title.y = element_text(size = 18, family = "serif"),
  axis.text.y = element_text(size = 14,family = "serif"))

col <- brewer.pal(9, "Set1")[1:4]


load("F1_sim_out/F1_R2");load("F2_sim_out/F2_R2");load("F3_sim_out/F3_R2");load("F4_sim_out/F4_R2")

F1_R2 <- data.frame(R2 = F1_R2, model = names(F1_R2))
rownames(F1_R2) <- NULL

F2_R2 <- data.frame(R2 = F2_R2, model = names(F2_R2))
rownames(F2_R2) <- NULL

F3_R2 <- data.frame(R2 = F3_R2, model = names(F3_R2))
rownames(F3_R2) <- NULL

F4_R2 <- data.frame(R2 = F4_R2, model = names(F4_R2))
rownames(F4_R2) <- NULL

F_R2 <- rbind(F1_R2,F2_R2,F3_R2,F4_R2)
F_R2$clinica <- rep(c("F1","F2","F3","F4"), each = 4)
rownames(F_R2) <- NULL

F_R2$model <- factor(F_R2$model, levels = c("Ridge", "RF", "GB", "NN"))
F_R2$clinica <- factor(F_R2$clinica, levels = c("F1","F2","F3","F4"))


barPlotHospital <- function(F_R2, title) {
  ggplot(F_R2, aes(x = clinica, y = R2, fill = model)) +
    geom_bar(stat = "identity", position=position_dodge(width = 0.58), width = 0.5, color ="black") +
    theme_minimal() + 
    ylim(0,0.85) + theme_title_r2 + theme_legend_r2 + theme_axis_r2 + ggtitle(title) +
    scale_fill_manual(
      values = c("Ridge" = col[1], "RF" = col[2], "GB" = col[3], "NN" = col[4]),
      labels = c("Ridge", "RF", "GB", "NN")) + 
    ylab("R^2 predittivo")
}


F_R2Plot <- barPlotHospital(F_R2, "Qualità complessiva dei modelli")
F_R2Plot


##### GRAFICI DI DEGRADAZIONE TEMPORALE #####
point_size <- 0.8
blu_points <- rgb(198,219,239, max = 255, alpha=60)
col = c("#525252","#FED976","#E31A1C")

#GRAFICI#
theme_title<- theme(
  plot.title = element_text(
    hjust = 0.5,  # Center the title
    size = 15,    # Set the font size
    color = "black",  # Set the font color
    family = "serif",
    face ="italic",
    margin = margin(b = 10)  # Add margin at the bottom
  ))

#Setting legenda
theme_legend <- theme(legend.title = element_blank(),
                      panel.border = element_rect(colour = "black", fill=NA),
                      legend.box.margin = margin(t = 1.5, l = 1.5,b =1,r=1.5),
                      legend.box.background = element_rect(colour = "black"),
                      legend.key.width = unit(0.5,"cm"),
                      legend.text = element_text(family ="serif", size =15))

#Setting assi
theme_axis <- theme(
  axis.title.x = element_text(size = 14, family = "serif"),
  axis.text.x = element_text(size = 12,family = "serif"),
  axis.title.y = element_text(size = 14, family = "serif"),
  axis.text.y = element_text(size = 12,family = "serif"))

theme_deg_plot <- theme_bw() + theme_title + theme_legend + theme_axis


ridge.plot <- function(models.attr, results, title) {
  
  ## Dataframed
  res.for.plot <- as.data.frame(t(results))
  res.for.plot$dt <- as.numeric(gsub("dt: ","",rownames(res.for.plot)))
  rownames(res.for.plot) <- NULL
  
  ## Togliamo 
  res.scale.for.plot <- res.for.plot
  
  ## Dividiamo gli MSE assoluti per renderli relativi.
  for (i in 1:nrow(models.attr)) {
    res.scale.for.plot[,i] <- res.scale.for.plot[,i]/models.attr[i,3]   ## Dividiamo per MSE a t0
  }
  
  ## Calcoliamo i quantili
  qt <- matrix(NA, nrow = max_dt, ncol = 4)
  colnames(qt) <- c("q25","q50","q75","dt")
  rownames(qt) <- 1:max_dt
  
  ## Popoliamo la matrice con i quantili
  for (i in 1:max_dt) {
    qt[i,] <- c(quantile(as.numeric(res.scale.for.plot[i,-ncol(res.scale.for.plot)]), probs = c(0.25,0.5,0.75)),i)
  }
  qt.for.plot <- as.data.frame(qt)
  
  
  ## Abbiamo bisogno dei singoli punti.
  res.scale.for.plot1 <- res.scale.for.plot[,c(1,ncol(res.scale.for.plot))]
  colnames(res.scale.for.plot1) <- c("values","dt")
  
  
  for (i in 2:(ncol(res.scale.for.plot)-1)) {
    tmp.df <- as.matrix(res.scale.for.plot[,c(i,ncol(res.scale.for.plot))])
    colnames(tmp.df) <- c("values","dt")
    res.scale.for.plot1 <- rbind(res.scale.for.plot1,tmp.df)
  }
  
  plot <- ggplot(data = res.scale.for.plot1, aes(x = dt, y = values)) + geom_point(stat="identity", col = blu_points, size = point_size) +
    geom_line(data=qt.for.plot, mapping = aes(x = dt, y = q25, color = "25esimo percentile")) +
    geom_line(data=qt.for.plot, mapping = aes(x = dt, y = q50, color = "mediana")) +
    geom_line( data=qt.for.plot, mapping = aes(x = dt, y = q75, color = "75esimo percentile")) +
    ylab("e_rel") + xlab("dT, giorni dopo la stima") + ggtitle(title) +
    scale_color_manual(name="",
                       breaks=c("25esimo percentile", "mediana", "75esimo percentile"),
                       values=c("25esimo percentile"=col[2], "mediana"=col[1], "75esimo percentile"=col[3]))
  
  return(plot)
}

rf.plot <- function(models.attr, results, title) {
  
  ## Dataframed
  res.for.plot <- as.data.frame(t(results))
  res.for.plot$dt <- as.numeric(gsub("dt: ","",rownames(res.for.plot)))
  rownames(res.for.plot) <- NULL
  
  ## Togliamo 
  res.scale.for.plot <- res.for.plot
  
  ## Dividiamo gli MSE assoluti per renderli relativi.
  for (i in 1:nrow(models.attr)) {
    res.scale.for.plot[,i] <- res.scale.for.plot[,i]/models.attr[i,4]   ## Dividiamo per MSE a t0
  }
  
  ## Calcoliamo i quantili
  qt <- matrix(NA, nrow = max_dt, ncol = 4)
  colnames(qt) <- c("q25","q50","q75","dt")
  rownames(qt) <- 1:max_dt
  
  ## Popoliamo la matrice con i quantili
  for (i in 1:max_dt) {
    qt[i,] <- c(quantile(as.numeric(res.scale.for.plot[i,-ncol(res.scale.for.plot)]), probs = c(0.25,0.5,0.75)),i)
  }
  qt.for.plot <- as.data.frame(qt)
  
  ## Proviamo a plottare.
  
  ## Abbiamo bisogno dei singoli punti.
  res.scale.for.plot1 <- res.scale.for.plot[,c(1,ncol(res.scale.for.plot))]
  colnames(res.scale.for.plot1) <- c("values","dt")
  
  
  for (i in 2:(ncol(res.scale.for.plot)-1)) {
    tmp.df <- as.matrix(res.scale.for.plot[,c(i,ncol(res.scale.for.plot))])
    colnames(tmp.df) <- c("values","dt")
    res.scale.for.plot1 <- rbind(res.scale.for.plot1,tmp.df)
  }
  
  plot <- ggplot(data = res.scale.for.plot1, aes(x = dt, y = values)) + geom_point(stat="identity", col = blu_points, size = point_size) +
    geom_line(data=qt.for.plot, mapping = aes(x = dt, y = q25, color = "25esimo percentile")) +
    geom_line(data=qt.for.plot, mapping = aes(x = dt, y = q50, color = "mediana")) +
    geom_line( data=qt.for.plot, mapping = aes(x = dt, y = q75, color = "75esimo percentile")) +
    ylab("e_rel") + xlab("dT, giorni dopo la stima") + ggtitle(title) +
    scale_color_manual(name="",
                       breaks=c("25esimo percentile", "mediana", "75esimo percentile"),
                       values=c("25esimo percentile"=col[2], "mediana"=col[1], "75esimo percentile"=col[3]))
  
  return(plot)
  
}

gb.plot <- function(models.attr, results, title) {
  
  ## Dataframed
  res.for.plot <- as.data.frame(t(results))
  res.for.plot$dt <- as.numeric(gsub("dt: ","",rownames(res.for.plot)))
  rownames(res.for.plot) <- NULL
  
  ## Togliamo 
  res.scale.for.plot <- res.for.plot
  
  ## Dividiamo gli MSE assoluti per renderli relativi.
  for (i in 1:nrow(models.attr)) {
    res.scale.for.plot[,i] <- res.scale.for.plot[,i]/models.attr[i,3]   ## Dividiamo per MSE a t0
  }
  
  ## Calcoliamo i quantili
  qt <- matrix(NA, nrow = max_dt, ncol = 4)
  colnames(qt) <- c("q25","q50","q75","dt")
  rownames(qt) <- 1:max_dt
  
  ## Popoliamo la matrice con i quantili
  for (i in 1:max_dt) {
    qt[i,] <- c(quantile(as.numeric(res.scale.for.plot[i,-ncol(res.scale.for.plot)]), probs = c(0.25,0.5,0.75)),i)
  }
  qt.for.plot <- as.data.frame(qt)
  
  ## Proviamo a plottare.
  
  ## Abbiamo bisogno dei singoli punti.
  res.scale.for.plot1 <- res.scale.for.plot[,c(1,ncol(res.scale.for.plot))]
  colnames(res.scale.for.plot1) <- c("values","dt")
  
  
  for (i in 2:(ncol(res.scale.for.plot)-1)) {
    tmp.df <- as.matrix(res.scale.for.plot[,c(i,ncol(res.scale.for.plot))])
    colnames(tmp.df) <- c("values","dt")
    res.scale.for.plot1 <- rbind(res.scale.for.plot1,tmp.df)
  }
  
  plot <- ggplot(data = res.scale.for.plot1, aes(x = dt, y = values)) + geom_point(stat="identity", col = blu_points, size = point_size) +
    geom_line(data=qt.for.plot, mapping = aes(x = dt, y = q25, color = "25esimo percentile")) +
    geom_line(data=qt.for.plot, mapping = aes(x = dt, y = q50, color = "mediana")) +
    geom_line( data=qt.for.plot, mapping = aes(x = dt, y = q75, color = "75esimo percentile")) +
    ylab("e_rel") + xlab("dT, giorni dopo la stima") + ggtitle(title) +
    scale_color_manual(name="",
                       breaks=c("25esimo percentile", "mediana", "75esimo percentile"),
                       values=c("25esimo percentile"=col[2], "mediana"=col[1], "75esimo percentile"=col[3]))
  
  return(plot)
  
}

nn.plot <- function(models.attr, results, title) {
  
  ## Dataframed
  res.for.plot <- as.data.frame(t(results))
  res.for.plot$dt <- as.numeric(gsub("dt: ","",rownames(res.for.plot)))
  rownames(res.for.plot) <- NULL
  
  ## Togliamo 
  res.scale.for.plot <- res.for.plot
  
  ## Dividiamo gli MSE assoluti per renderli relativi.
  for (i in 1:nrow(models.attr)) {
    res.scale.for.plot[,i] <- res.scale.for.plot[,i]/as.numeric(models.attr[i,3])   ## Dividiamo per MSE a t0
  }
  
  ## Calcoliamo i quantili
  qt <- matrix(NA, nrow = max_dt, ncol = 4)
  colnames(qt) <- c("q25","q50","q75","dt")
  rownames(qt) <- 1:max_dt
  
  ## Popoliamo la matrice con i quantili
  for (i in 1:max_dt) {
    qt[i,] <- c(quantile(as.numeric(res.scale.for.plot[i,-ncol(res.scale.for.plot)]), probs = c(0.25,0.5,0.75)),i)
  }
  qt.for.plot <- as.data.frame(qt)
  
  ## Proviamo a plottare.
  
  ## Abbiamo bisogno dei singoli punti.
  res.scale.for.plot1 <- res.scale.for.plot[,c(1,ncol(res.scale.for.plot))]
  colnames(res.scale.for.plot1) <- c("values","dt")
  
  
  for (i in 2:(ncol(res.scale.for.plot)-1)) {
    tmp.df <- as.matrix(res.scale.for.plot[,c(i,ncol(res.scale.for.plot))])
    colnames(tmp.df) <- c("values","dt")
    res.scale.for.plot1 <- rbind(res.scale.for.plot1,tmp.df)
  }
  
  plot <- ggplot(data = res.scale.for.plot1, aes(x = dt, y = values)) + geom_point(stat="identity", col = blu_points, size = point_size) +
    geom_line(data=qt.for.plot, mapping = aes(x = dt, y = q25, color = "25esimo percentile")) +
    geom_line(data=qt.for.plot, mapping = aes(x = dt, y = q50, color = "mediana")) +
    geom_line( data=qt.for.plot, mapping = aes(x = dt, y = q75, color = "75esimo percentile")) +
    ylab("e_rel") + xlab("dT, giorni dopo la stima") + ggtitle(title) +
    scale_color_manual(name="",
                       breaks=c("25esimo percentile", "mediana", "75esimo percentile"),
                       values=c("25esimo percentile"=col[2], "mediana"=col[1], "75esimo percentile"=col[3]))
  
  return(plot)
  
}


## F1 ##
max_t0 <- 100
max_dt <- 503
days_selected <- seq(365,365+max_t0, by = 5)

## F2 ##
max_t0 <- 100
max_dt <- 503
days_selected <- seq(365,365+max_t0, by = 5)

## F3 ##
max_t0 <- 60
max_dt <- 202
days_selected <- seq(365,365+max_t0, by = 2)

## F4 ##
max_t0 <- 60
max_dt <- 134
days_selected <- seq(365,365+max_t0, by = 2)



setwd("C:/Users/User/Documents/AI AGING/SimulationsMachine/EnvironForCompactSimulations/HOSPITAL DATA/F4_sim_out")
load(file = "models/models.ridge")
load(file = "results/results.ridge")
load(file = "models/models.rf")
load(file = "results/results.rf")
load(file = "models/models.gb")
load(file = "results/results.gb")
load(file = "models/models.nn")
load(file = "results/results.nn")


ridge <- ridge.plot(models.attr.ridge, results.ridge,"Ridge") + theme_deg_plot + ylim(0.7,2)
rf <- rf.plot(models.attr.rf, results.rf, "RF") + theme_deg_plot + ylim(0.7,2)
gb <- gb.plot(models.attr.gb, results.gb, "GB") + theme_deg_plot + ylim(0.7,2)
nn <- nn.plot(models.attr.nn, results.nn, "NN") + theme_deg_plot + ylim(0.7,2)

plot_finale <- ridge + rf + gb + nn +
  plot_layout(guides="collect", ncol=2, nrow=2, byrow=TRUE) &
  theme(legend.box.background = element_rect(color = "black", linewidth = 1)) +
  theme(legend.position="bottom")
plot_finale

ggsave(filename="F4_degen.pdf", plot=plot_finale, width=10, height=8, device="pdf")





### GRAFICO R2 INIZIALE DEI MODELLI NEL FRAMEWORK ###
setwd(paste0("C:/Users/User/Documents/AI AGING/SimulationsMachine/",
             "EnvironForCompactSimulations/HOSPITAL DATA/F4_sim_out"))
load(file = "models/models.ridge");load(file = "models/models.rf")
load(file = "models/models.gb");load(file = "models/models.nn")

mean_R2s <- data.frame(days = days_selected, ridge=models.attr.ridge$R2_pred, 
                       rf=models.attr.rf$R2_pred,
                       gb=models.attr.gb$R2_pred,
                       nn = models.attr.nn$R2_pred)

theme_title_r2 <- theme(
  plot.title = element_text(
    hjust = 0.5,  # Center the title
    size = 20,    # Set the font size
    color = "black",  # Set the font color
    family = "serif",
    face ="italic",
    margin = margin(b = 10)  # Add margin at the bottom
  ))

theme_legend_r2 <- theme(legend.position = c(0.5, 0.1), legend.title = element_blank(),
                         panel.border = element_rect(colour = "black", fill=NA),
                         legend.box.margin = margin(t = 1, l = 1,b =1.5,r=1),
                         legend.box.background = element_rect(colour = "black"),
                         legend.direction = "horizontal", legend.key.width = unit(0.5,"cm"),
                         legend.text = element_text(family ="serif", size =15))

theme_axis_r2 <- theme(
  axis.title.x = element_text(size = 18, family = "serif"),
  axis.text.x = element_text(size = 14,family = "serif"),
  axis.title.y = element_text(size = 18, family = "serif"),
  axis.text.y = element_text(size = 14,family = "serif"))

col <- brewer.pal(9, "Set1")[1:4]

meanQuality <- data.frame(quality = c(mean(models.attr.ridge$R2_pred),
                                      mean(models.attr.rf$R2_pred),
                                      mean(models.attr.gb$R2_pred),
                                      mean(models.attr.nn$R2_pred)))
rownames(meanQuality) <- c("Ridge","RF","GB","NN")

plot_R2 <- ggplot(data = mean_R2s, aes(x = days)) +
  geom_line(aes(y = ridge, color = "Ridge"), linewidth =1) +
  geom_line(aes(y = rf, color = "RF"), linewidth =1) +
  geom_line(aes(y = gb, color = "GB"), linewidth =1) +
  geom_line(aes(y = nn, color = "NN"), linewidth =1) +
  scale_color_manual(
    values = c("Ridge" = col[1], "RF" = col[2], "GB" = col[3], "NN" = col[4]),
    labels = c(paste0("Ridge (",round(meanQuality["Ridge",1],2),")"),
               paste0("RF (",round(meanQuality["RF",1],2),")"),
               paste0("GB (",round(meanQuality["GB",1],2),")"),
               paste0("NN (",round(meanQuality["NN",1],2),")")),
    breaks = c("Ridge", "RF", "GB", "NN")) + 
  ggtitle("Qualità iniziale - Clinica F4") + ylab("R^2 predittivo") + xlab("t_0") + ylim(0,0.4) + 
  scale_x_continuous(breaks=c(365,385,405,425), limits=c(365,425))
#   scale_x_continuous(breaks=c(365,390,415,440,465), limits=c(365,465))

plot_R2 <- plot_R2 + theme_bw() + theme_title_r2 + theme_axis_r2 + theme_legend_r2
plot_R2

ggsave(filename="F4_R2.pdf", plot = plot_R2, device ="pdf", width=10, height = 4.5)






