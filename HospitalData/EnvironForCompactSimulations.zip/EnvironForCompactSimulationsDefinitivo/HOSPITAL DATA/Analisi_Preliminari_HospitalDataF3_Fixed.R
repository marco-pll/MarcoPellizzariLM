###################### ANALISI PRELIMINARI F3 ############################
# Analisi preliminari dei dataset contenenti gli accessi alle cliniche.

#Link ad un articolo che effettua l'analisi su questi dati.
#https://www.nature.com/articles/s42256-020-0176-3.epdf?sharing_token=99haQmpHDaMRMlUEA0uTq9RgN0jAjWel9jnR3ZoTv0Or00bxapyX95_3YHLe-3btzcevNHJ1Eue8nMqeqVFDColPoHRvA9tAfycPJi4EBC67ZdgFe1qIuM6WY6iTm3A9Fvq3CVpHv5f550m-VvFS5m0LiyM5dPRHyN_PqhHOoas%3D
#Origine dei dati.
#https://medicalanalytics.group/operational-data-challenge/
rm(list=ls())
#Utilizzare le informazioni fino a 20 minuti prima dell'apuntamento.

setwd("C:/Users/User/Documents/AI AGING/HOSPITAL DATA")
hospital <- read.csv("WaitData_3.csv", sep=";") #La prima pagina del file WaitData.Published
orig <- colnames(hospital)
hospital[,orig[90:104]] <- NULL
colnames(hospital)



#####   Pulizia del dataset  #####

#Dati mancanti
NAs <- rep(0,ncol(hospital))
names(NAs) <- colnames(hospital)
for (i in 1:ncol(hospital)) {
  NAs[i] <- sum(is.na(hospital[,i]))
}

sum(NAs) #Non hanno dati mancanti, e non ci sono etichette che li rappresentino.

#Variabili costanti eliminate
const <- c()
for (i in colnames(hospital)) {
  if(length(unique(hospital[,i])) == 1) {
    const <- c(const,i)
  }
}
# Non ci sono variabili con valori costanti.
hospital[, const] <- NULL


##  Costruzione di feature rilevanti  ##
tmp<- as.POSIXct(hospital$x_ScheduledDTTM)
hospital$x_ScheduledDTTM <- tmp

## Otteniamo il giorno
hospital$date <- as.Date(hospital$x_ScheduledDTTM)

## Il giorno rispetto alla prima osservazione disponibile.
hospital$days <- as.numeric(difftime(hospital$date, min(hospital$date), units = "days"))

## Traformazione in data-tempo
hospital$x_ArrivalDTTM <- as.POSIXct(hospital$x_ArrivalDTTM)
hospital$x_BeginDTTM <- as.POSIXct(hospital$x_BeginDTTM)

## Riordiniamo il dataset in ordine di arrivo.
hospital <- hospital[order(hospital$x_ArrivalDTTM),]


#####   RAPPRESENTAZIONE GRAFICA   #####
library(RColorBrewer)
library(ggplot2)
library(patchwork)

theme_title_data <- theme(
  plot.title = element_text(
    hjust = 0.5,  # Center the title
    size = 20,    # Set the font size
    color = "black",  # Set the font color
    family = "serif",
    face ="italic",
    margin = margin(b = 10)  # Add margin at the bottom
  ))

theme_axis_data <- theme(
  axis.title.x = element_text(size = 18, family = "serif"),
  axis.text.x = element_text(size = 14,family = "serif"),
  axis.title.y = element_text(size = 18, family = "serif"),
  axis.text.y = element_text(size = 14,family = "serif"))

theme_legend_data <- theme(legend.position = c(0.5, 0.9), legend.title = element_blank(),
                           panel.border = element_rect(colour = "black", fill=NA),
                           legend.box.margin = margin(t = 1, l = 1,b =1.5,r=1),
                           legend.box.background = element_rect(colour = "black"),
                           legend.direction = "horizontal", legend.key.width = unit(0.5,"cm"),
                           legend.text = element_text(family ="serif", size =15))


get.daily.means.1 <- function(data) {
  data.dm <- data.frame(Days = unique(data$days))
  data.dm$output.mean <- apply(as.matrix(data.dm$Days),1,function(x) mean(data$Wait[data$days == x])) 
  return(data.dm)
}

mobile.average <- function(order = m, data = df_for_plot){
  ma <- apply(as.matrix(data$Days),1,function(x) mean(data$output.mean[data$Days >= (x-order) & data$Days <= (x+order)]))
  ma[c(1:order,(length(ma)-order+1):length(ma))] <- NA
  return(ma)
}

m <- 15 #Per la media mobile
df_for_plot <- get.daily.means.1(hospital)[,c("Days","output.mean")]
df_for_plot$mobile_av <- mobile.average(m, df_for_plot)

data_plot <- ggplot(data=df_for_plot, aes(x=Days)) +
  geom_line(aes(y = output.mean, color = "Media giornaliera"), linewidth = 1) + 
  geom_line(aes(y = mobile_av, color = "Media mobile"),linewidth=0.5) + 
  scale_color_manual(
    values = c("Media giornaliera" = "lightblue", "Media mobile" = "black"),
    labels = c("Media giornaliera", "Media mobile"),
    breaks = c("Media giornaliera", "Media mobile")) + 
  ggtitle("Ambulatorio F3") + ylab("tempo di attesa") + xlab("giorni")


data_plot <- data_plot + theme_bw() + theme_title_data + theme_axis_data + theme_legend_data
data_plot
# Molte meno osservazioni. 

setwd("C:/Users/User/Documents/AI AGING/SimulationsMachine/EnvironForCompactSimulations/HOSPITAL DATA")
ggsave(filename="F3_sim_out/F3_plot.pdf", plot = data_plot,
       device = "pdf", width = 10, height = 4)



#####    Pulizia delle variabili    #####

#Creazione di altre variabili rilevanti
arrival_date <- as.Date(hospital$x_ArrivalDTTM)    
opening <- paste(arrival_date,"07:30:00")          
opening <- as.POSIXct(opening)    #Apertura della clinica

# Arrivo alla clinica, in minuti passati dall'apertura.
hospital$x_ArrivalDTTM_Quant <- as.numeric(difftime(hospital$x_ArrivalDTTM, opening, units = "mins"))

## Variabili rese fattoriali
hospital$IsLast <- factor(hospital$IsLast)
hospital$IsFirst <- factor(hospital$IsFirst)
hospital$NoneInProgress <- factor(hospital$NoneInProgress)
hospital$NoneCompleted <- factor(hospital$NoneCompleted)
hospital$NoneInLine <- factor(hospital$NoneInLine)
hospital$DayOfWeek <- factor(hospital$DayOfWeek)

## Variabili categoriali rese quantitative.
hospital$Month <- as.numeric(hospital$Month)
hospital$DayOfYear <- as.numeric(hospital$DayOfYear)

##################  Nuove variabili ####################
#Definizione di nuove variabili, utili per la previsione del ritardo.

hospital$early <- as.numeric(difftime(hospital$x_ScheduledDTTM,
                                      hospital$x_ArrivalDTTM, units = "mins"))

## Ritardo o anticipo.
hospital$how_late <- ifelse(hospital$early <0, hospital$early, 0)   #Minuti di ritardo rispetto all'appuntamento
hospital$how_early <- ifelse(hospital$early >=0, hospital$early, 0) #Minuti di anticipo rispetto all'appuntamento



hospital$NumScheduledSameSlot <- 0         #Clienti allo stesso orario
hospital$InLineNumberForScheduled <- 1     #Posizione del cliente nella fila per l'orario prestabilito.
for (i in 1:nrow(hospital)) {
  tmp <- hospital[hospital$x_ScheduledDTTM == hospital$x_ScheduledDTTM[i],]
  hospital$NumScheduledSameSlot[i] <- nrow(tmp) - 1
  
  ## Ordine nella fila.
  hospital$InLineNumberForScheduled[i] <- nrow(tmp[tmp$x_ArrivalDTTM <= hospital$x_ArrivalDTTM[i],])
}


hospital$NumScheduledBeforeSlot30 <- 0
hospital$NumScheduledBeforeSlot15 <- 0

for (i in 1:nrow(hospital)) {
  tmp <- hospital[(hospital$days == hospital$days[i]),]
  tmp1 <- tmp[as.numeric(difftime(tmp$x_ScheduledDTTM,hospital$x_ScheduledDTTM[i], units = "mins")) >= -30 &
                as.numeric(difftime(tmp$x_ScheduledDTTM,hospital$x_ScheduledDTTM[i], units = "mins")) < 0,]
  if(nrow(tmp1) != 0) hospital$NumScheduledBeforeSlot30[i] <- nrow(tmp1)
  tmp2 <- tmp[as.numeric(difftime(tmp$x_ScheduledDTTM,hospital$x_ScheduledDTTM[i], units = "mins")) >= -15 &
                as.numeric(difftime(tmp$x_ScheduledDTTM,hospital$x_ScheduledDTTM[i], units = "mins")) < 0,]
  if(nrow(tmp2) != 0) hospital$NumScheduledBeforeSlot15[i] <- nrow(tmp2)
}

hospital$Schedule_Minute  <- format(hospital$x_ScheduledDTTM, format = "%M")
hospital$Schedule_Minute <- ifelse(hospital$Schedule_Minute != "00" & hospital$Schedule_Minute != "15" & 
                                     hospital$Schedule_Minute != "30" & hospital$Schedule_Minute != "45",
                                   "Altro",
                                   hospital$Schedule_Minute)
hospital$Schedule_Minute <- as.factor(hospital$Schedule_Minute) 

#Rispetto a FLowCount, questo è legato all'appuntamento, non al momento di arrivo.


hospital$perc_delay <- 0               #Percentuale di incontri iniziati in ritardo nella giornata
hospital$perc_delay_high <- 0          #Percentuale di incontri con ritardo elevato

for (i in 1:nrow(hospital)) {
  
  #Quelli che avevano l'appuntamento prima.
  tmp <- hospital[(hospital$days == hospital$days[i]),]
  tmp <- tmp[as.numeric(difftime(tmp$x_BeginDTTM, hospital$x_ArrivalDTTM[i], units = "mins")) < 0,]
  tmp <- tmp[tmp$Schedule_Minute != "Altro",]
  
  #Elimino anche gli ingressi troppo recenti.
  if (nrow(tmp) != 0) {
    hospital$perc_delay[i] <- sum(tmp$Wait > 0)/nrow(tmp)
    hospital$perc_delay_high[i] <- sum(tmp$Wait >= 15)/nrow(tmp)
  }
}

## L'ora Scheduled prevista. Quantitativa.
scheduled_date <- as.Date(hospital$x_ScheduledDTTM)
opening <- paste(scheduled_date,"07:30:00")
opening <- as.POSIXct(opening)


hospital$Scheduled_Quant <- as.numeric(difftime(hospital$x_ScheduledDTTM, opening, units = "mins"))

## NumberDelayedInLine e SUmDelay in line non hanno senso come variabili, le ricalcolo a modo mio.
## SumDelayWaitingLine è il tempo che quelli prima devono aspettare per arrivare al momento scheduled.

## Ridefiniamo le variabili NumberDelayedInLine
hospital$SumDelayInLine <- 0          ##Somma del ritardo della gente in line, o dell'anticipo.
#Permette di cheattare somewhat.

for (i in 1:nrow(hospital)) {
  tmp <- hospital[hospital$days == hospital$days[i],]
  ## Waiting in line al momento dell'arrivo. Questi sono i tizi che precedono l'arrivato.
  tmp <- tmp[tmp$x_ArrivalDTTM < hospital$x_ArrivalDTTM[i] & tmp$x_BeginDTTM > hospital$x_ArrivalDTTM[i],]
  if (nrow(tmp)!=0) {
    tmp_wait <- tmp[tmp$x_BeginDTTM > tmp$x_ScheduledDTTM & tmp$x_ScheduledDTTM < hospital$x_ArrivalDTTM[i],]
    hospital$SumDelayInLine[i] <- sum(as.numeric(difftime(tmp_wait$x_ScheduledDTTM, hospital$x_ArrivalDTTM[i], units = "mins")))
  }
}


#Ritardo degli ultimi 2 pazienti.
hospital$LastPatient1 <- 0
hospital$LastPatient2 <- 0
hospital$MedianWaitTime <- 0

for (i in 1:nrow(hospital)) {
  tmp <- hospital[hospital$days == hospital$days[i],]
  ## I pazienti che hanno iniziato al momento dell'arrivo
  tmp <- tmp[tmp$x_BeginDTTM < hospital$x_ArrivalDTTM[i],]
  
  if (nrow(tmp)!=0) {
    hospital$MedianWaitTime[i] <- median(tmp$Wait)
    tmp <- tmp[order(tmp$x_BeginDTTM),]   #Riordinato
    hospital$LastPatient1[i] <- tmp$Wait[nrow(tmp)]  #Wait time del più recente.
    if (nrow(tmp) >1 ) hospital$LastPatient2[i] <- tmp$Wait[nrow(tmp) - 1]
  }
}

# Ritardi nei giorni precedenti
hospital$WeekDelay <- NA             #Ritardo medio dei 7 giorni precedenti
hospital$previousDayDelay <- NA      #Ritardo medio del giorno precedente

uDays <- unique(hospital$days)
#Iniziamo dal secondo giorno, perché il primo avrà per forza dato mancante.
for (i in 2:length(uDays)) {
  hospital[hospital$days == uDays[i],"previousDayDelay"] <-
    mean(hospital$Wait[hospital$days == uDays[i-1]], na.rm = TRUE)
  hospital[hospital$days == uDays[i],"WeekDelay"] <- 
    mean(hospital$Wait[hospital$days <= (uDays[i]-1) & hospital$days >= (uDays[i] - 7)])
}

write.csv(hospital, "C:/Users/User/Documents/AI AGING/SimulationsMachine/EnvironForCompactSimulations/HOSPITAL DATA/FixedData/F3_fixFR.csv", 
          row.names=FALSE)
hospital <- read.csv("C:/Users/User/Documents/AI AGING/SimulationsMachine/EnvironForCompactSimulations/HOSPITAL DATA/FixedData/F3_fixFR.csv")
head(hospital)




escluse <- c("early")


hospital <- na.omit(hospital)
hospital$IsLast <- factor(hospital$IsLast)
hospital$IsFirst <- factor(hospital$IsFirst)
hospital$NoneInProgress <- factor(hospital$NoneInProgress)
hospital$NoneCompleted <- factor(hospital$NoneCompleted)
hospital$NoneInLine <- factor(hospital$NoneInLine)
hospital$DayOfWeek <- factor(hospital$DayOfWeek)
hospital$x_ArrivalDTTM  <- as.POSIXct(hospital$x_ArrivalDTTM)

## Variabili categoriali rese quantitative.
hospital$Month <- as.numeric(hospital$Month)
hospital$DayOfYear <- as.numeric(hospital$DayOfYear)
hospital$Schedule_Minute <- as.factor(hospital$Schedule_Minute)



vars <- colnames(hospital)
## Togliamo le variabili che non usiamo nelle analisi.
X <- setdiff(vars,escluse)
escluse2 <- c("Wait","x_ArrivalDTTM","x_ScheduledDTTM","x_BeginDTTM","date","days")
X <- setdiff(X,escluse2)

## Adesso togliamo i fattori e standardizziamo le quantitative.
quant <- c()
for(var in X) {
  if(is.numeric(hospital[,var])) quant <- c(quant,var)
}
qual <- setdiff(X,quant)
hospital[,quant] <- scale(hospital[,quant])





set.seed(1030)
train <- sample(1:nrow(hospital), floor(0.85*nrow(hospital)))
training <- hospital[train,]
training <- training[order(training[,"x_ArrivalDTTM"]),]
testing <- hospital[-train,]


##### REGRESSIONE RIDGE INTERO DATASET #####
library(glmnet)

ridge_estimates <- function(training, train_set, test_set, lambda) {
  
  tmp_ridge <- glmnet(x = training[train_set,-c(days.pos,out.pos)], y = training[train_set,out.pos],alpha = 0, lambda = lambda)
  
  pred_ridge = predict(tmp_ridge, newx=training[test_set,-c(days.pos,out.pos)])
  errori_ridge = apply((training[test_set, out.pos] - pred_ridge)^2,2,mean)
  
  return(errori_ridge)
}

cv_ridge <- function(training, nsets, lambda, time_wise) {
  cat("\nCV...\n")
  
  if(time_wise == FALSE) {
    order <- sample(1:nrow(training),nrow(training)) 
  }
  
  errori_ridge <- matrix(NA,nrow=nsets, ncol=length(lambda))
  
  #Ciclo per ogni fold
  for (i in 1:nsets) {
    
    if(time_wise == TRUE) {
      
      dim_subset = floor(nrow(training)/(nsets+1))
      train_set <- 1:(i*dim_subset)
      test_set <- (i*dim_subset + 1):((i+1)*dim_subset)  ## Blocco successivo.
      
    }
    if(time_wise == FALSE) {
      
      dim_subset = floor(nrow(training)/nsets)
      test_set <- ((i-1)*dim_subset + 1):(i*dim_subset)
      train_set <- order[-test_set]
      test_set <- order[test_set]
    }
    
    errori_ridge[i,] <- ridge_estimates(training, train_set, test_set, lambda)
  }
  
  return(errori_ridge)
}

train_x <-  model.matrix(~.,training[,c(X,"days","Wait")])[,-1]
test_x <-  model.matrix(~.,testing[,c(X,"days","Wait")])[,-1]

days.pos <- ncol(train_x) - 1
out.pos <- ncol(train_x)


#Convalida incrociata sul primo anno.
set.seed(1031)
lambda = 10^seq(2, -5, length=150)
m.ridge.cv <- cv_ridge(training = train_x, nsets = 4, lambda = lambda, time_wise = TRUE)
lambda.use <- lambda[which.min(apply(m.ridge.cv,2,mean))]

m.ridge <- glmnet(x = train_x[,-c(days.pos,out.pos)],y = train_x[,out.pos],
                  alpha = 0, lambda = lambda.use, family = "gaussian")

fits <- predict(m.ridge, newx = test_x[,-c(days.pos,out.pos)])
SSE <- sum((fits - test_x[,out.pos])^2)
DEV <- sum((test_x[,out.pos] - mean(test_x[,out.pos]))^2)
R2_ridge <- 1 - SSE/DEV  #R2 sul test set.
R2_ridge #0.67




##### RANDOM FOREST SUL PRIMO ANNO ####
library(ranger)
library(foreach)
library(doParallel)
library(parallelly)
library(doRNG)


rf_estimates <- function(training, train_set, test_set, reg.grid, seed_off) {
  
  cl <- makeCluster(1)
  clusterExport(cl, c("X"))
  registerDoParallel(cl)
  registerDoRNG(1000 + seed_off)  
  
  r <- foreach (j = 1:nrow(reg.grid), .packages = "ranger") %dopar%  {
    tmp_rf <- ranger(Wait ~ .,
                     data=training[train_set,],
                     num.tree = reg.grid[j,1],
                     importance = "impurity",
                     mtry = reg.grid[j,2], oob.error=FALSE)
    
    test.fit <- mean((training[test_set,"Wait"] - predict(tmp_rf,training[test_set,-ncol(training)])$prediction)^2)
    
    list(errori = test.fit)
  }
  
  stopCluster(cl)
  
  errori <- rep(NA,nrow(reg.grid))
  
  for(i in 1:nrow(reg.grid)) {
    errori[i] <- r[[i]]$errori
  }
  
  return(errori)
  
}

cv_rf <- function(training, nsets, reg.grid, time_wise) {
  
  if(time_wise == FALSE) {
    order <- sample(1:nrow(training),nrow(training)) 
  }
  
  errori_rf <- matrix(NA,nrow=nsets, ncol=nrow(reg.grid))
  
  #Inizia il ciclo per ogni subset.
  for (i in 1:nsets) {
    cat("\nFold: ",i,"\n")
    if(time_wise == TRUE) {
      
      dim_subset = floor(nrow(training)/(nsets+1))
      train_set <- 1:(i*dim_subset)
      test_set <- (i*dim_subset + 1):((i+1)*dim_subset)  ## Blocco successivo.
      
    }
    if(time_wise == FALSE) {
      
      dim_subset = floor(nrow(training)/nsets)
      test_set <- ((i-1)*dim_subset + 1):(i*dim_subset)
      train_set <- order[-test_set]
      test_set <- order[test_set]
    }
    
    errori_rf[i,] <- rf_estimates(training, train_set, test_set, reg.grid, i)
  }
  
  return(errori_rf)
}

train_x <-  model.matrix(~.,training[,c(X,"days","Wait")])[,-1]
test_x <-  model.matrix(~.,testing[,c(X,"days","Wait")])[,-1]

days.pos <- ncol(train_x) - 1
out.pos <- ncol(train_x)

mtry <- seq(40,100, by = 10)
num.trees <- c(350) # 730 di CV MSE. Nessun miglioramento aumentando gli alberi
reg.grid <- expand.grid(num.trees,mtry)
colnames(reg.grid) <- c("Num trees","mtry")

set.seed(1033)

m.rf.cv <- cv_rf(train_x[,-days.pos], nsets = 4, reg.grid,time_wise = TRUE)
opt <- reg.grid[which.min(apply(m.rf.cv,2,mean)),]

m.rf <- ranger(Wait ~ . ,
               data=train_x[,-days.pos],
               num.tree = opt[1,1],
               importance = "impurity",
               mtry = opt[1,2], oob.error=FALSE)

fits <- predict(m.rf,test_x[,-days.pos])$prediction
SSE <- sum((fits - test_x[,out.pos])^2)
DEV <- sum((test_x[,out.pos] - mean(test_x[,out.pos]))^2)
R2_rf <- 1 - SSE/DEV  #R2 sul test set.
R2_rf  #0.67




#######    GRADIENT BOOSTING    #######
library(gbm)

tree.num <- function(shrink, depth) {
  
  trees = 1500
  #trees = 3000
  
  if(depth == 1) trees = trees*2.5
  if(depth == 2) trees = trees*1.8
  if(depth ==3) trees = trees*1.5
  if(depth>=4) trees = trees*1.2
  
  return(trees)
}

gb_estimates_par <- function(training, train_set, test_set, reg.grid, seed_off) {
  
  #Ridefinita all'interno, perché da fuori dava problemi.
  tree.num <- function(shrink, depth) {
    
    trees = 1500
    #trees = 3000
    
    if(depth == 1) trees = trees*2.5
    if(depth == 2) trees = trees*1.8
    if(depth ==3) trees = trees*1.5
    if(depth>=4) trees = trees*1.2
    
    return(trees)
  }
  
  cl <- makeCluster(cores)
  registerDoParallel(cl)
  registerDoRNG(1000 + seed_off)
  
  r <- foreach (j = 1:nrow(reg.grid), .packages = "gbm") %dopar%  {
    
    num.tree <- tree.num(shrink = reg.grid[j,2], depth =reg.grid[j,1])
    
    tmp_gb <- gbm(Wait~., data = training[train_set,], distribution = "gaussian",
                  n.trees = num.tree,
                  interaction.depth = reg.grid[j,1], shrinkage = reg.grid[j,2] )
    
    test.fit <- predict(tmp_gb, newdata = training[test_set,-ncol(training)], n.trees=1:num.tree)
    
    mses <- apply(test.fit, 2, function (pred) mean((training[test_set,"Wait"] - pred)^2))
    
    list(errori = mses[which.min(mses)], alberi = round(which.min(mses)/num.tree,2))
  }
  
  stopCluster(cl)
  
  errori <- rep(NA,nrow(grid))
  alberi <- rep(NA,nrow(grid))
  for(i in 1:nrow(grid)) {
    errori[i] <- r[[i]]$errori
    alberi[i] <- r[[i]]$alberi
  }
  
  risultati_list <- list(Errori = errori, Num_Alberi = alberi)
  return(risultati_list)
}

cv_gb <- function(training, nsets, reg.grid, time_wise) {
  
  if(time_wise == FALSE) {
    order <- sample(1:nrow(training),nrow(training)) 
  }
  
  errori_gb <- matrix(NA,nrow=nsets, ncol=nrow(reg.grid))
  num_alberi <- matrix(NA,nrow=nsets, ncol=nrow(reg.grid))
  
  #Inizia il ciclo per ogni subset.
  for (i in 1:nsets) {
    
    if(time_wise == TRUE) {
      
      dim_subset = floor(nrow(training)/(nsets+1))
      train_set <- 1:(i*dim_subset)
      test_set <- (i*dim_subset + 1):((i+1)*dim_subset)  ## Blocco successivo.
      
    }
    if(time_wise == FALSE) {
      
      dim_subset = floor(nrow(training)/nsets)
      test_set <- ((i-1)*dim_subset + 1):(i*dim_subset)
      train_set <- order[-test_set]
      test_set <- order[test_set]
    }
    
    cat("\n",i,":\n")
    estimates <- gb_estimates_par(training, train_set, test_set, reg.grid, i)
    errori_gb[i,] <- estimates$Errori
    num_alberi[i,] <- estimates$Num_Alberi
  }
  
  return(list("results" = errori_gb,"alberi" = num_alberi))
}

train_x <-  training[,c(X,"days","Wait")]
test_x <-  testing[,c(X,"days","Wait")]

days.pos <- ncol(train_x) - 1
out.pos <- ncol(train_x)

##Griglia
shrinkage <- c(0.08)
depths <- 1:4
grid <- expand.grid(depths,shrinkage)
colnames(grid) <- c("depth","shrink")

cores=4
m.gb.cv <- cv_gb(train_x[,-days.pos], nsets = 4, grid,time_wise = TRUE)
opt <- grid[which.min(apply(m.gb.cv$results,2,mean)),]

set.seed(1034)
train <- sample(1:nrow(train_x), floor(nrow(train_x)*0.85))
training_x <- train_x[train,-c(days.pos)]
testing_x <- train_x[-train,-c(days.pos)]

m.gb <- gbm(Wait ~ ., data = training_x, distribution = "gaussian",
            n.trees = tree.num(shrink = opt[1,2], depth = opt[1,1]),
            interaction.depth = opt[1,1], shrinkage = opt[1,2])

test.fit <- predict(m.gb, newdata = testing_x, n.trees=1:tree.num(shrink = opt[1,2], depth = opt[1,1]))

mses <- apply(test.fit, 2, function (pred) mean((testing_x[,"Wait"] - pred)^2))
opt_tree <- which.min(mses)

fits <- predict(m.gb,test_x[,-c(days.pos)], n.trees=opt_tree)
SSE <- sum((fits - test_x[,out.pos])^2)
DEV <- sum((test_x[,out.pos] - mean(test_x[,out.pos]))^2)
R2_gb <- 1 - SSE/DEV  #R2 sul test set.
R2_gb     #R2 è 0.68



####    RETE NEURALE    ####
library(keras)
library(tensorflow)

create_nn <- function(layers, size, n_input, seed) {
  
  set.seed(seed)
  seeds <- runif(layers + 1, min = 1000, max = 10000)
  
  model <- keras_model_sequential()
  
  model %>% layer_dense(name = "Hidden1",
                        units = size[1],
                        activation = "relu",
                        input_shape = n_input,
                        kernel_initializer = initializer_random_normal(seed = seeds[1]))
  
  if (layers >= 2) {
    for (h in 2:layers) {
      model %>% layer_dense(name = paste0("Hidden",h),
                            units = size[h],
                            activation = "relu",
                            kernel_initializer = initializer_random_normal(seed = seeds[h]))
    }
  }
  
  model %>% layer_dense(name = "Output",
                        units = 1,
                        activation = "linear",
                        kernel_initializer = initializer_random_normal(seed = seeds[layers + 1]))
  
  model %>% compile(loss = "mean_squared_error",
                    optimizer ="Adam",
                    metrics = "mean_squared_error")
  
  return(model)
}

train_x <-  as.data.frame(model.matrix(~.,training[,c(X,"days","Wait")])[,-1])
test_x <-  as.data.frame(model.matrix(~.,testing[,c(X,"days","Wait")])[,-1])

days.pos <- ncol(train_x) - 1
out.pos <- ncol(train_x)

tensorflow::set_random_seed(1036)
set.seed(1036)


reps=3 #Punti di partenza casuali
layers <- 3
size <- c(200,200,200)

early_stop <- callback_early_stopping(monitor = "val_mean_squared_error",
                                      min_delta = 0,
                                      patience = 8,
                                      verbose = 0)



train <- sample(1:nrow(train_x), floor(nrow(train_x)*0.8))
training_x <- as.matrix(train_x[train,-c(days.pos,out.pos)])
validation_x <- as.matrix(train_x[-train,-c(days.pos,out.pos)])
training_y <- train_x[train,out.pos]
validation_y <- train_x[-train,out.pos]

seeds <- floor(runif(reps,min=1000, max=9999))
models_reps <- rep(NA,reps)
epochs_reps <- rep(NA,reps)

for (j in 1:reps) {
  m.nn <- create_nn(layers, size, ncol(training_x), seeds[j])
  
  storia <- m.nn %>% fit(x = training_x,
                         y = training_y,
                         batch_size = ceiling(nrow(training_x)/2),
                         epochs = 1000,
                         verbose = 1,
                         validation_data = list(validation_x,validation_y),
                         callbacks = early_stop)
  
  models_reps[j] <- storia$metrics$val_mean_squared_error[which.min(storia$metrics$val_mean_squared_error)]
  epochs_reps[j] <- which.min(storia$metrics$val_mean_squared_error)
}

seed <- seeds[which.min(models_reps)]
epoche <- epochs_reps[which.min(models_reps)]

m.nn <- create_nn(layers, size, ncol(training_x), seed)

storia <- m.nn %>% fit(x = training_x,
                       y = training_y,
                       batch_size = ceiling(nrow(training_x)/2),
                       epochs = epoche,
                       verbose = 1,
                       validation_data = list(validation_x,validation_y),
                       callbacks = early_stop)

## R2.
fits.nn <- predict(m.nn, as.matrix(test_x[,-c(days.pos,out.pos)]), verbose = 0)
SSE <- sum((test_x[,out.pos] - fits.nn)^2)
DEV <- sum((test_x[,out.pos] - mean(test_x[,out.pos]))^2)
R2_nn <- 1 - SSE/DEV
R2_nn # 0.67 di R2.


### SALVATAGGIO ###

F3_R2 <- c(R2_ridge, R2_rf, R2_gb, R2_nn)
names(F3_R2) <- c("Ridge","RF","GB","NN")

save(F3_R2, file = "HOSPITAL DATA/F3_sim_out/F3_R2")





###### FRAMEWORK PER LO STUDIO DELLA DEGENERAZIONE #######

rm(list=ls())
setwd("C:/Users/User/Documents/AI AGING/SimulationsMachine/EnvironForCompactSimulations/HOSPITAL DATA")
hospital <- read.csv("C:/Users/User/Documents/AI AGING/SimulationsMachine/EnvironForCompactSimulations/HOSPITAL DATA/FixedData/F3_fixFR.csv")
head(hospital)
escluse <- c("early")
hospital <- na.omit(hospital)
hospital$IsLast <- factor(hospital$IsLast)
hospital$IsFirst <- factor(hospital$IsFirst)
hospital$NoneInProgress <- factor(hospital$NoneInProgress)
hospital$NoneCompleted <- factor(hospital$NoneCompleted)
hospital$NoneInLine <- factor(hospital$NoneInLine)
hospital$DayOfWeek <- factor(hospital$DayOfWeek)
hospital$x_ArrivalDTTM  <- as.POSIXct(hospital$x_ArrivalDTTM)

## Variabili categoriali rese quantitative.
hospital$Month <- as.numeric(hospital$Month)
hospital$DayOfYear <- as.numeric(hospital$DayOfYear)
hospital$Schedule_Minute <- as.factor(hospital$Schedule_Minute)

data = hospital

vars <- colnames(data)
escluse <- c("early")
#escluse <- c(escluse,"early")
X <- setdiff(vars,escluse)
escluse2 <- c("Wait","x_ArrivalDTTM","x_ScheduledDTTM","x_BeginDTTM","date","days")
X <- setdiff(X,escluse2)

# STANDARDIZZAZIONE #

quant <- c()
for(var in X) {
  if(is.numeric(hospital[,var])) quant <- c(quant,var)
}
qual <- setdiff(X,quant)
#hospital[,quant] <- scale(hospital[,quant])


MSSE_t0 <- function(data_x, days_selected)  {
  
  MSSE <- data.frame(MSSE_t0 = NA)
  
  for (i in days_selected) {
    t0_train <- (data_x[,"days"] > i & data_x[,"days"] <= (i + mse_window))
    MSSE[i - 364,] <- mean((data_x[t0_train,"Wait"] - mean(data_x[t0_train,"Wait"]))^2)
  }
  
  return(MSSE)
}

##########     PARAMETRI    ##############################

nsets <- 4              #Fold della convalida incrociata
retrain <- 20           #Multiplo di 3, distanza in giorni tra una regolazione ed un'altra
max_t0 <- 60           #Spostamento massimo, in giorni, dell'insieme di stima
finestra <- 20          #Giorni nella finestar mobile
mse_window <- 20        #Giorni nel test set

## Lunghezza del periodo di degenerazione.
max_dt <- max(data$days) - (364 + max_t0) - finestra - mse_window

## Giorni ai quali stimare i modelli.
days_selected <- seq(365,365+max_t0, by = 2)

#Calcolo MSE di previsione.
MSSE_days_sel <- na.omit(MSSE_t0(data, days_selected))


###DOVE METTERE I RISULTATI###
path = "F3_sim_out"




#### RIDGE ####

library(glmnet)

ridge_estimates <- function(training, train_set, test_set, lambda) {
  
  tmp_ridge <- glmnet(x = training[train_set,-c(days.pos,out.pos)], y = training[train_set,out.pos],alpha = 0, lambda = lambda)
  
  pred_ridge = predict(tmp_ridge, newx=training[test_set,-c(days.pos,out.pos)])
  errori_ridge = apply((training[test_set, out.pos] - pred_ridge)^2,2,mean)
  
  return(errori_ridge)
}

cv_ridge <- function(training, nsets, lambda, time_wise) {
  cat("\nCV...\n")
  
  if(time_wise == FALSE) {
    order <- sample(1:nrow(training),nrow(training)) 
  }
  
  errori_ridge <- matrix(NA,nrow=nsets, ncol=length(lambda))
  
  #Ciclo per ogni fold
  for (i in 1:nsets) {
    
    if(time_wise == TRUE) {
      
      dim_subset = floor(nrow(training)/(nsets+1))
      train_set <- 1:(i*dim_subset)
      test_set <- (i*dim_subset + 1):((i+1)*dim_subset)  ## Blocco successivo.
      
    }
    if(time_wise == FALSE) {
      
      dim_subset = floor(nrow(training)/nsets)
      test_set <- ((i-1)*dim_subset + 1):(i*dim_subset)
      train_set <- order[-test_set]
      test_set <- order[test_set]
    }
    
    errori_ridge[i,] <- ridge_estimates(training, train_set, test_set, lambda)
  }
  
  return(errori_ridge)
}

## Valori della degenerazione.
results <- matrix(NA,nrow = max_t0 + 1, ncol = max_dt)
colnames(results) <- paste0("dt: ",seq(1:max_dt))
rownames(results) <- seq(0:(max_t0))

##Caratteristiche dei modelli
models.attr <- matrix(NA,nrow = max_t0 + 1, ncol = 3)
rownames(models.attr) <- seq(0:(max_t0))
colnames(models.attr) <- c("R2","Lambda use","MSE a t0")

vars <- colnames(data)
escluse <- c("early")
X <- setdiff(vars,escluse)
escluse2 <- c("Wait","x_ArrivalDTTM","x_ScheduledDTTM","x_BeginDTTM","date","days")
X <- setdiff(X,escluse2)

data_x <- data[,c(X,"days","Wait")]
data_x <- model.matrix(~.,na.omit(data_x))[,-1]

days.pos <- ncol(data_x) - 1
out.pos <- ncol(data_x)

## Griglia di Lambda da usare
lambda = 10^seq(2, -5, length=150)
lambda.use <- NA

set.seed(1022)
for (i in days_selected) {
  
  #STANDARDIZZAZIONE DEL PRIMO ANNO DI TRAINING.
  train <- (data_x[,days.pos] >= (i - 364) & data_x[,days.pos] <= i)
  data_x_anno <- data_x[train,]
  centro <- colMeans(data_x_anno[,quant])
  scala <- apply(data_x_anno[,quant],2,sd)
  data_x_anno[,quant] <- scale(data_x_anno[,quant], center = centro, scale = scala)
  
  if(((i - 365) %% retrain) == 0) {
    
    m.ridge.cv <- cv_ridge(training = data_x_anno, nsets = nsets, lambda = lambda, time_wise = TRUE)
    lambda.use <- lambda[which.min(apply(m.ridge.cv,2,mean))]
  }
  
  m.ridge <- glmnet(x = data_x_anno[,-c(days.pos,out.pos)],y = data_x_anno[,out.pos],
                    alpha = 0, lambda = lambda.use, family = "gaussian")
  
  
  ## Mse a t0 con finestra successiva.
  t0_train <- (data_x[,days.pos] > i & data_x[,days.pos] <= (i + mse_window))
  data_x_window <- data_x[t0_train,-c(days.pos,out.pos)]
  data_x_window[,quant] <- scale(data_x_window[,quant], center = centro, scale = scala)
  fits.t0 <- predict(m.ridge, newx = data_x_window)
  mse.t0 <- mean((fits.t0 - data_x[t0_train,out.pos])^2)
  
  ## 
  models.attr[i - 364,2] <- lambda.use
  models.attr[i - 364,3] <- mse.t0
  
  ## R2 di training
  fits <- predict(m.ridge, newx = data_x_anno[,-c(days.pos,out.pos)])
  SSE <- sum((fits - data_x[train,out.pos])^2)
  DEV <- sum((data_x[train,out.pos] - mean(data_x[train,out.pos]))^2)
  models.attr[i - 364,1] <- 1 - SSE/DEV
  
  ## Previsioni del modello
  for_fits <- data_x[,days.pos] >= (i + mse_window + 1) & data_x[,days.pos] < (i + mse_window + max_dt + finestra)
  to_predict <- data_x[for_fits,out.pos]
  to_predict_X <- data_x[for_fits,-c(days.pos,out.pos)]
  to_predict_X[,quant] <- scale(to_predict_X[,quant], center = centro, scale = scala)
  
  
  ## Mi salvo anche i giorni.
  days_to_use <- data_x[for_fits,days.pos]
  
  ##Tutte le previsioni da i + 1 fino a i + 765, finestra poi di 30
  fits <- predict(m.ridge, newx = to_predict_X)
  
  ## Finestre mobili
  for (j in 1:max_dt) {
    
    test <- (days_to_use >= (i + j + mse_window) & days_to_use < (i + j + mse_window + finestra))
    mse <- mean((to_predict[test] - fits[test])^2)
    
    results[i-364,j] <- mse
  }
  
  print(((i - 364)/(1 + max_t0))*100)
}

models.attr.ridge <- as.data.frame(na.omit(models.attr))
results.ridge <- as.data.frame(na.omit(results))
models.attr.ridge$R2_pred <- 1 - models.attr.ridge$`MSE a t0`/MSSE_days_sel$MSSE_t0


# Salvataggio
save(models.attr.ridge, file =paste0(path,"/models/models.ridge"))
save(results.ridge, file =paste0(path,"/results/results.ridge"))

#####   RANDOM FOREST    ###########
library(ranger)
library(foreach)
library(doParallel)
library(parallelly)
library(doRNG)


rf_estimates <- function(training, train_set, test_set, reg.grid, seed_off) {
  
  cl <- makeCluster(1)
  clusterExport(cl, c("X"))
  registerDoParallel(cl)
  registerDoRNG(1022 + seed_off)  
  
  r <- foreach (j = 1:nrow(reg.grid), .packages = "ranger") %dopar%  {
    tmp_rf <- ranger(Wait ~ .,
                     data=training[train_set,],
                     num.tree = reg.grid[j,1],
                     importance = "impurity",
                     mtry = reg.grid[j,2], oob.error=FALSE)
    
    test.fit <- mean((training[test_set,"Wait"] - predict(tmp_rf,training[test_set,-ncol(training)])$prediction)^2)
    
    list(errori = test.fit)
  }
  
  stopCluster(cl)
  
  errori <- rep(NA,nrow(reg.grid))
  
  for(i in 1:nrow(reg.grid)) {
    errori[i] <- r[[i]]$errori
  }
  
  return(errori)
  
}

cv_rf <- function(training, nsets, reg.grid, time_wise, reg_num) {
  
  if(time_wise == FALSE) {
    order <- sample(1:nrow(training),nrow(training)) 
  }
  
  errori_rf <- matrix(NA,nrow=nsets, ncol=nrow(reg.grid))
  
  #Inizia il ciclo per ogni subset.
  for (i in 1:nsets) {
    cat("\nFold: ",i,"\n")
    if(time_wise == TRUE) {
      
      dim_subset = floor(nrow(training)/(nsets+1))
      train_set <- 1:(i*dim_subset)
      test_set <- (i*dim_subset + 1):((i+1)*dim_subset)  ## Blocco successivo.
      
    }
    if(time_wise == FALSE) {
      
      dim_subset = floor(nrow(training)/nsets)
      test_set <- ((i-1)*dim_subset + 1):(i*dim_subset)
      train_set <- order[-test_set]
      test_set <- order[test_set]
    }
    
    errori_rf[i,] <- rf_estimates(training, train_set, test_set, reg.grid, i*reg_num)
  }
  
  return(errori_rf)
}

## Valori della degenerazione.
results <- matrix(NA,nrow = max_t0 + 1, ncol = max_dt)
colnames(results) <- paste0("dt: ",seq(1:max_dt))
rownames(results) <- seq(0:(max_t0))

##Caratteristiche dei modelli
models.attr <- matrix(NA,nrow = max_t0 + 1, ncol = 4)
rownames(models.attr) <- seq(0:(max_t0))
colnames(models.attr) <- c("R2","NumTrees","Mtry","MSE a t0")

vars <- colnames(data)
escluse <- c("early")
#escluse <- c(escluse,"early")
X <- setdiff(vars,escluse)
escluse2 <- c("Wait","x_ArrivalDTTM","x_ScheduledDTTM","x_BeginDTTM","date","days")
X <- setdiff(X,escluse2)


data_x <- na.omit(data[,c(X,"days","Wait")])

days.pos <- ncol(data_x) - 1
out.pos <- ncol(data_x)


## Griglia
mtry <- seq(40,100, by = 10)
num.trees <- c(500)
reg.grid <- expand.grid(num.trees,mtry)
colnames(reg.grid) <- c("Num trees","mtry")


######  Regolazione  ########

set.seed(1023)

regulated <- c()
mse <- list()

k = 0

for (i in 365:(365+max_t0)) {
  
  if((i - 365) %% retrain == 0) {
    
    k = k + 1
    cat("\nRegolazione numero:",k)
    
    data_to_use <- (data_x[,days.pos]>= (i - 364) & data_x[,days.pos]<=i)
    
    data_x_anno <- data_x[data_to_use,]
    centro <- colMeans(data_x_anno[,quant])
    scala <- apply(data_x_anno[,quant],2,sd)
    data_x_anno[,quant] <- scale(data_x_anno[,quant], center = centro, scale = scala)
    
    output <- cv_rf(data_x_anno[,-days.pos], nsets, reg.grid, time_wise = TRUE, k) #k è per seedare.
    
    # Salvo gli alberi.
    mse[[k]] <- output
    
    mse_medi <- apply(output,2,mean)
    
    ##Elemento ottimale della griglia.
    opt <- which.min(mse_medi)
    regulated <- rbind(regulated, c(i,opt, as.numeric(reg.grid[opt,])))
  }
}

colnames(regulated) <- c("Numero","Optimal","Trees","Mtry")
regulated.rf <- regulated



#####  DEGENERAZIONE  #####

mtry_use <- NA
numTrees_use <- NA

cl <- makeCluster(1)
registerDoParallel(cl)
registerDoRNG(1025)

r <- foreach (i = days_selected, .packages = "ranger") %dopar% {
  
  ## Dati da usare
  data_to_use <- (data_x[,days.pos]>= (i - 364) & data_x[,days.pos]<=i)
  data_x_anno <- data_x[data_to_use,]
  centro <- colMeans(data_x_anno[,quant])
  scala <- apply(data_x_anno[,quant],2,sd)
  data_x_anno[,quant] <- scale(data_x_anno[,quant], center = centro, scale = scala)
  
  ## Aggiorniamo la struttura.
  reg_to_use <- sum(i >= regulated[,1])
  opt <- regulated[reg_to_use,2]
  
  m.rf <- ranger(Wait ~ . ,
                 data=data_x_anno[,c(X,"Wait")],
                 num.tree = reg.grid[opt,1],
                 importance = "impurity",
                 mtry = reg.grid[opt,2], oob.error=FALSE)
  
  ## R2.
  fits.rf <- predict(m.rf,data_x_anno[,X])$prediction
  SSE <- sum((data_x[data_to_use,out.pos] - fits.rf)^2)
  DEV <- sum((data_x[data_to_use,out.pos] - mean(data_x[data_to_use,out.pos]))^2)
  
  R2 <- 1 - SSE/DEV
  
  ## MSE a t0 mse_window.
  t0_train <- (data_x[,days.pos] > i & data_x[,days.pos] <= (i + mse_window))
  data_x_window <- data_x[t0_train,-c(days.pos,out.pos)]
  data_x_window[,quant] <- scale(data_x_window[,quant], center = centro, scale = scala)
  
  fits.t0 <- predict(m.rf, data_x_window)$prediction
  mse.t0 <- mean((fits.t0 - data_x[t0_train,out.pos])^2)
  
  ## Previsioni del modello
  for_fits <- data_x[,days.pos] >= (i + mse_window + 1) & data_x[,days.pos] < (i + mse_window + max_dt + finestra)
  to_predict <- data_x[for_fits,out.pos]
  to_predict_X <- data_x[for_fits,-c(days.pos,out.pos)]
  to_predict_X[,quant] <- scale(to_predict_X[,quant], center = centro, scale = scala)
  
  ## Mi salvo anche i giorni.
  days_to_use <- data_x[for_fits,days.pos]
  
  ##Tutte le previsioni da i + 1 fino a i + max_dt, finestra poi di finestra
  fits <- predict(m.rf, to_predict_X)$prediction
  
  prestazioni <- rep(NA,max_dt)
  for (j in 1:max_dt) {
    
    test <- (days_to_use >= (i + j + mse_window) & days_to_use < (i + j + mse_window + finestra))
    mse <- mean((to_predict[test] - fits[test])^2)
    
    prestazioni[j] <- mse
  }
  
  list(R2 = R2, optimal = opt, mse_t0 = mse.t0, prestazioni = prestazioni, mtry = reg.grid[opt,2], numTrees =reg.grid[opt,1])
}
stopCluster(cl)

for (j in 1:length(days_selected)) {
  models.attr[days_selected[j] - 364,"R2"] <- r[[j]]$R2
  models.attr[days_selected[j] - 364,"NumTrees"] <- r[[j]]$numTrees
  models.attr[days_selected[j] - 364,"MSE a t0"] <- r[[j]]$mse_t0
  models.attr[days_selected[j] - 364,"Mtry"] <- r[[j]]$mtry
  results[days_selected[j] - 364,] <- r[[j]]$prestazioni
}


models.attr.rf <- as.data.frame(na.omit(models.attr))
results.rf <- as.data.frame(na.omit(results))
models.attr.rf$R2_pred <- 1 - models.attr.rf$`MSE a t0`/MSSE_days_sel$MSSE_t0

#Salvataggio 
save(models.attr.rf, file =paste0(path,"/models/models.rf"))
save(results.rf, file =paste0(path,"/results/results.rf"))


#####  GRADIENT BOOSTING   #####
library(gbm)
cores = 4

#Numero di alberi da stimare come funzione della profondità.
tree.num <- function(shrink, depth) {
  
  #trees = 3000
  trees = 1000
  #trees = 6000
  #trees = 8000
  #trees = 12000
  
  if(depth == 1) trees = trees*2.5
  if(depth == 2) trees = trees*1.8
  if(depth ==3) trees = trees*1.5
  if(depth>=4) trees = trees*1.2
  
  return(trees)
}

gb_estimates_par <- function(training1, train_set, test_set, reg.grid, seed_off) {
  
  #Ridefinita all'interno, perché da fuori dava problemi.
  tree.num <- function(shrink, depth) {
    
    #trees = 3000
    trees = 1000
    #trees = 6000
    #trees 8000
    #trees = 12000
    
    if(depth == 1) trees = trees*2.5
    if(depth == 2) trees = trees*1.8
    if(depth ==3) trees = trees*1.5
    if(depth>=4) trees = trees*1.2
    
    return(trees)
  }
  
  cl <- makeCluster(cores)
  registerDoParallel(cl)
  registerDoRNG(1010 + seed_off)
  
  r <- foreach (j = 1:nrow(reg.grid), .packages = "gbm") %dopar%  {
    
    num.tree <- tree.num(shrink = reg.grid[j,2], depth =reg.grid[j,1])
    
    tmp_gb <- gbm(Wait~., data = training1[train_set,], distribution = "gaussian",
                  n.trees = num.tree,
                  interaction.depth = reg.grid[j,1], shrinkage = reg.grid[j,2] )
    
    test.fit <- predict(tmp_gb, newdata = training1[test_set,-ncol(training1)], n.trees=1:num.tree)
    
    mses <- apply(test.fit, 2, function (pred) mean((training1[test_set,"Wait"] - pred)^2))
    
    list(errori = mses[which.min(mses)], alberi = round(which.min(mses)/num.tree,2))
  }
  
  stopCluster(cl)
  
  errori <- rep(NA,nrow(grid))
  alberi <- rep(NA,nrow(grid))
  for(i in 1:nrow(grid)) {
    errori[i] <- r[[i]]$errori
    alberi[i] <- r[[i]]$alberi
  }
  
  risultati_list <- list(Errori = errori, Num_Alberi = alberi)
  return(risultati_list)
}

cv_gb <- function(training1, nsets, reg.grid, time_wise) {
  
  if(time_wise == FALSE) {
    order <- sample(1:nrow(training1),nrow(training1)) 
  }
  
  errori_gb <- matrix(NA,nrow=nsets, ncol=nrow(reg.grid))
  num_alberi <- matrix(NA,nrow=nsets, ncol=nrow(reg.grid))
  
  #Inizia il ciclo per ogni subset.
  for (i in 1:nsets) {
    
    if(time_wise == TRUE) {
      
      dim_subset = floor(nrow(training1)/(nsets+1))
      train_set <- 1:(i*dim_subset)
      test_set <- (i*dim_subset + 1):((i+1)*dim_subset)  ## Blocco successivo.
      
    }
    if(time_wise == FALSE) {
      
      dim_subset = floor(nrow(training1)/nsets)
      test_set <- ((i-1)*dim_subset + 1):(i*dim_subset)
      train_set <- order[-test_set]
      test_set <- order[test_set]
    }
    
    cat("\n",i,":\n")
    estimates <- gb_estimates_par(training1, train_set, test_set, reg.grid, i)
    errori_gb[i,] <- estimates$Errori
    num_alberi[i,] <- estimates$Num_Alberi
  }
  
  return(list("results" = errori_gb,"alberi" = num_alberi))
}

#Sceglie la profondità dell'albero sulla base del primo anno.
tree_depth <- function(data_x, grid) {
  
  data_to_use <- (data_x[,days.pos]>= 1 & data_x[,days.pos]<=365) #Usa il primo anno
  #Primo anno e standardizzo.
  data_x_anno <- data_x[data_to_use,]
  centro <- colMeans(data_x_anno[,quant])
  scala <- apply(data_x_anno[,quant],2,sd)
  data_x_anno[,quant] <- scale(data_x_anno[,quant], center = centro, scale = scala)
  
  output <- cv_gb(data_x_anno[,-days.pos], nsets, grid,time_wise = TRUE)
  print(output$alberi)
  print(apply(output$results,2,mean))
  opt <- which.min(apply(output$results,2,mean))
  return(c(365,opt,as.numeric(grid[opt,])))
  
}

vars <- colnames(data)
escluse <- c("early")
X <- setdiff(vars,escluse)
escluse2 <- c("Wait","x_ArrivalDTTM","x_ScheduledDTTM","x_BeginDTTM","date","days")
X <- setdiff(X,escluse2)

data_x <- na.omit(data[,c(X,"days","Wait")])
days.pos <- ncol(data_x) - 1
out.pos <- ncol(data_x)



#### PROVA USANDO ONE-HOT ENCODING ####
# E' sostanzialmente identico.



##Valori della degenerazione
results <- matrix(NA,nrow = max_t0 + 1, ncol = max_dt)
colnames(results) <- paste0("dt: ",seq(1:(max_dt)))
rownames(results) <- seq(0:(max_t0))

##Caratteristiche dei modelli
models.attr <- matrix(NA,nrow = max_t0 + 1, ncol = 4)
rownames(models.attr) <- seq(0:(max_t0))
colnames(models.attr) <- c("R2","Grid_opt","MSE a t0","Alberi")

##Griglia
shrinkage <- c(0.08)
depths <- 1:4
grid <- expand.grid(depths,shrinkage)
colnames(grid) <- c("depth","shrink")

## Profondità degli alberi. La scelgo all'inizio tramite convalida incrociata.
set.seed(1016)
regulated <- c()
regulated <- rbind(regulated,tree_depth(data_x,grid))

###### Degenerazione ######

cl <- makeCluster(cores)
registerDoParallel(cl)
registerDoRNG(1017)              #Rende la parallelizazzione replicabile.

system.time(
  r <- foreach (i = days_selected, .packages = "gbm") %dopar% {
    ## Dati da usare
    data_to_use <- (data_x[,days.pos]>= (i - 364) & data_x[,days.pos]<=i)
    
    ##PRIMO ANNO STANDARDIZZATO
    data_x_anno <- data_x[data_to_use,]
    centro <- colMeans(data_x_anno[,quant])
    scala <- apply(data_x_anno[,quant],2,sd)
    data_x_anno[,quant] <- scale(data_x_anno[,quant], center = centro, scale = scala)
    ## Aggiorniamo la struttura.
    reg_to_use <- sum(i >= regulated[,1])
    
    ## Creo i training e i test set.
    train <- sample(1:nrow(data_x_anno), floor(nrow(data_x_anno)*0.85))
    training <- data_x_anno[train,-c(days.pos)]
    testing <- data_x_anno[-train,-c(days.pos)]
    
    opt <- regulated[reg_to_use,2]
    num.tree <- tree.num(shrink = grid[opt,2], depth = grid[opt,1])
    m.gb <- gbm(Wait~., data = training, distribution = "gaussian",
                n.trees = num.tree,
                interaction.depth = grid[opt,1], shrinkage = grid[opt,2] )
    
    ## Errori sul testing, per trovare il modello migliore.
    test.fit <- predict(m.gb, newdata = testing, n.trees=1:num.tree)
    
    mses <- apply(test.fit, 2, function (pred) mean((testing[,"Wait"] - pred)^2))
    
    ##Numero di alberi ottimale.
    opt_tree <- which.min(mses)
    
    ## R2.
    fits.gb <- predict(m.gb,data_x_anno[,-c(days.pos,out.pos)], n.trees=opt_tree)
    SSE <- sum((data_x_anno[,out.pos] - fits.gb)^2)
    DEV <- sum((data_x_anno[,out.pos] - mean(data_x_anno[,out.pos]))^2)
    
    R2 <- 1 - SSE/DEV
    
    ##Elemento utilizzato.
    optimal_used <- regulated[reg_to_use,2]
    
    ## MSE a t0 mse_window.
    t0_train <- (data_x[,days.pos] > i & data_x[,days.pos] <= (i + mse_window))
    data_x_window <- data_x[t0_train,-c(days.pos,out.pos)]
    data_x_window[,quant] <- scale(data_x_window[,quant], center = centro, scale = scala)
    
    fits.t0 <- predict(m.gb, data_x_window, n.trees=opt_tree)
    mse.t0 <- mean((fits.t0 - data_x[t0_train,out.pos])^2)
    
    ## SALVO l'MSE a t0.
    for_fits <- data_x[,days.pos] >= (i + mse_window + 1) & data_x[,days.pos] < (i + mse_window + max_dt + finestra)
    to_predict <- data_x[for_fits,out.pos]
    to_predict_X <- data_x[for_fits,-c(days.pos,out.pos)]
    to_predict_X[,quant] <- scale(to_predict_X[,quant], center = centro, scale = scala)
    
    ## Mi salvo anche i giorni.
    days_to_use <- data_x[for_fits,days.pos]
    
    ##Tutte le previsioni da i + 1 fino a i + max_dt, finestra poi di finestra
    fits <- predict(m.gb, to_predict_X, n.trees=opt_tree)
    
    ## Finestre mobili
    
    prestazioni <- rep(NA,max_dt)
    for (j in 1:max_dt) {
      
      test <- (days_to_use >= (i + j + mse_window) & days_to_use < (i + j + mse_window + finestra))
      mse <- mean((to_predict[test] - fits[test])^2)
      
      prestazioni[j] <- mse
    }
    
    list(R2 = R2, optimal = optimal_used,opt_tree = round(opt_tree/num.tree,2), mse_t0 = mse.t0, prestazioni = prestazioni)
    
  }
)

stopCluster(cl)

for (j in 1:length(days_selected)) {
  models.attr[days_selected[j] - 364,"R2"] <- r[[j]]$R2
  models.attr[days_selected[j] - 364,"Grid_opt"] <- r[[j]]$optimal
  models.attr[days_selected[j] - 364,"MSE a t0"] <- r[[j]]$mse_t0
  models.attr[days_selected[j] - 364,"Alberi"] <- r[[j]]$opt_tree
  results[days_selected[j] - 364,] <- r[[j]]$prestazioni
}

models.attr.gb <- as.data.frame(na.omit(models.attr))
results.gb <- as.data.frame(na.omit(results))
models.attr.gb$R2_pred <- 1 - models.attr.gb$`MSE a t0`/MSSE_days_sel$MSSE_t0

#plot(as.numeric(results.gb[10,]), type="l")

#Salvataggio
save(models.attr.gb, file =paste0(path,"/models/models.gb"))
save(results.gb, file =paste0(path,"/results/results.gb"))



#####    RETI NEURALI    #####
library(keras)
library(tensorflow)
library(doRNG)
library(foreach)
library(doParallel)
library(parallelly)

create_nn <- function(layers, size, n_input, seed) {
  
  set.seed(seed)
  seeds <- runif(layers + 1, min = 1000, max = 10000)
  
  model <- keras_model_sequential()
  
  model %>% layer_dense(name = "Hidden1",
                        units = size[1],
                        activation = "relu",
                        input_shape = n_input,
                        kernel_initializer = initializer_random_normal(seed = seeds[1]))
  
  if (layers >= 2) {
    for (h in 2:layers) {
      model %>% layer_dense(name = paste0("Hidden",h),
                            units = size[h],
                            activation = "relu",
                            kernel_initializer = initializer_random_normal(seed = seeds[h]))
    }
  }
  
  model %>% layer_dense(name = "Output",
                        units = 1,
                        activation = "linear",
                        kernel_initializer = initializer_random_normal(seed = seeds[layers + 1]))
  
  model %>% compile(loss = "mean_squared_error",
                    optimizer ="Adam",
                    metrics = "mean_squared_error")
  
  return(model)
}

vars <- colnames(data)
escluse <- c("early")
#escluse <- c(escluse,"early")
X <- setdiff(vars,escluse)
escluse2 <- c("Wait","x_ArrivalDTTM","x_ScheduledDTTM","x_BeginDTTM","date","days")
X <- setdiff(X,escluse2)

data_x <- na.omit(data[,c(X,"days","Wait")])
data_x <- cbind(model.matrix(~., data=data_x[,X])[,-1],data_x[,c("days","Wait")])
data_x <- as.data.frame(data_x)
X <- setdiff(colnames(data_x),escluse2)

days.pos <- ncol(data_x) - 1
out.pos <- ncol(data_x)

##Valori della degenerazione
results <- matrix(NA,nrow = max_t0 + 1, ncol = max_dt)
colnames(results) <- paste0("dt: ",seq(1:(max_dt)))
rownames(results) <- seq(0:(max_t0))

##Caratteristiche dei modelli
models.attr <- matrix(NA,nrow = max_t0 + 1, ncol = 4)
rownames(models.attr) <- seq(0:(max_t0))
colnames(models.attr) <- c("R2","Grid_opt","MSE a t0","Epoche")

tensorflow::set_random_seed(1027)
set.seed(1027)

reps=3 #Punti di partenza casuali
layers <- 3
size <- c(200,200,200)
#size <- c(50,50,50) #Usato questa perché un po' meglio.

cl <- makeCluster(4)
clusterExport(cl, c("layers","size","X"))
registerDoParallel(cl)
registerDoRNG(1027)


system.time(
  r <- foreach (i = days_selected, .packages = c("keras","tensorflow"), .export= c("create_nn")) %dopar% {
    
    early_stop <- callback_early_stopping(monitor = "val_mean_squared_error",
                                          min_delta = 0,
                                          patience = 8,
                                          verbose = 0)
    
    ## Dati da usare
    data_to_use <- (data_x[,days.pos]>= (i - 364) & data_x[,days.pos]<=i)
    
    ## Creo i training e i test set.
    data_x_anno <- data_x[data_to_use,]
    centro <- colMeans(data_x_anno[,quant])
    scala <- apply(data_x_anno[,quant],2,sd)
    data_x_anno[,quant] <- scale(data_x_anno[,quant], center = centro, scale = scala)
    
    
    train <- sample(1:nrow(data_x_anno), floor(nrow(data_x_anno)*0.8))
    training_x <- as.matrix(data_x_anno[train,X])
    validation_x <- as.matrix(data_x_anno[-train,X])
    training_y <- data_x_anno[train,"Wait"]
    validation_y <- data_x_anno[-train,"Wait"]
    
    ## Genero i seed
    seeds <- floor(runif(reps,min=1000, max=9999))
    models_reps <- rep(NA,reps)
    epochs_reps <- rep(NA,reps)
    
    for (j in 1:reps) {
      m.nn <- create_nn(layers, size, length(X), seeds[j])
      
      storia <- m.nn %>% fit(x = training_x,
                             y = training_y,
                             batch_size = ceiling(nrow(training_x)/2),
                             epochs = 1000,
                             verbose = 1,
                             validation_data = list(validation_x,validation_y),
                             callbacks = early_stop)
      
      models_reps[j] <- storia$metrics$val_mean_squared_error[which.min(storia$metrics$val_mean_squared_error)]
      epochs_reps[j] <- which.min(storia$metrics$val_mean_squared_error)
    }
    
    ## Ristimo il modello migliore, usando il numero di epoche ottimali.
    seed <- seeds[which.min(models_reps)]
    epoche <- epochs_reps[which.min(models_reps)]
    
    m.nn <- create_nn(layers, size, length(X), seed)
    
    storia <- m.nn %>% fit(x = training_x,
                           y = training_y,
                           batch_size = ceiling(nrow(training_x)/2),
                           epochs = epoche,
                           verbose = 1,
                           validation_data = list(validation_x,validation_y),
                           callbacks = early_stop)
    
    ## R2.
    fits.nn <- predict(m.nn, as.matrix(data_x_anno[,-c(days.pos,out.pos)]), batch_size = 32, verbose = 0)
    SSE <- sum((data_x_anno[,"Wait"] - fits.nn)^2)
    DEV <- sum((data_x_anno[,"Wait"] - mean(data_x_anno[,"Wait"]))^2)
    
    R2 <- 1 - SSE/DEV
    
    ## MSE a t0 mse_window.
    t0_train <- (data_x[,days.pos] > i & data_x[,days.pos] <= (i + mse_window))
    data_x_window <- data_x[t0_train,-c(days.pos,out.pos)]
    data_x_window[,quant] <- scale(data_x_window[,quant], center = centro, scale = scala)
    
    fits.t0 <- predict(m.nn, as.matrix(data_x_window), batch_size = 32, verbose = 0)
    mse.t0 <- mean((fits.t0 - data_x[t0_train,out.pos])^2)
    
    
    for_fits <- data_x[,days.pos] >= (i + mse_window + 1) & data_x[,days.pos] < (i + mse_window + max_dt + finestra)
    to_predict <- data_x[for_fits,out.pos]
    to_predict_X <- data_x[for_fits,-c(days.pos,out.pos)]
    to_predict_X[,quant] <- scale(to_predict_X[,quant], center = centro, scale = scala)
    
    ## Mi salvo anche i giorni.
    days_to_use <- data_x[for_fits,days.pos]
    
    ##Tutte le previsioni da i + 1 fino a i + max_dt, finestra poi di finestra
    fits <- predict(m.nn, as.matrix(to_predict_X), batch_size = 32, verbose = 0)
    
    ## Finestre mobili
    
    prestazioni <- rep(NA,max_dt)
    for (j in 1:max_dt) {
      
      test <- (days_to_use >= (i + j + mse_window) & days_to_use < (i + j + mse_window + finestra))
      mse <- mean((to_predict[test] - fits[test])^2)
      
      prestazioni[j] <- mse
    }
    
    list(R2 = R2,epoche = epoche, mse_t0 = mse.t0, prestazioni = prestazioni)
    
  }
)
stopCluster(cl)

for (j in 1:length(days_selected)) {
  models.attr[days_selected[j] - 364,"R2"] <- r[[j]]$R2
  #  models.attr[days_selected[j] - 364,"Grid_opt"] <- r[[j]]$optimal         residuo.
  models.attr[days_selected[j] - 364,"MSE a t0"] <- r[[j]]$mse_t0
  models.attr[days_selected[j] - 364,"Epoche"] <- r[[j]]$epoche
  results[days_selected[j] - 364,] <- r[[j]]$prestazioni
}

models.attr[!is.na(models.attr[,"R2"]),"Grid_opt"] <- 1  #Per sistemare la tabella senza modificare il codice.
models.attr.nn <- as.data.frame(na.omit(models.attr))
results.nn <- as.data.frame(na.omit(results))
models.attr.nn$R2_pred <- 1 - models.attr.nn$`MSE a t0`/MSSE_days_sel$MSSE_t0

#Salvataggio
save(models.attr.nn, file =paste0(path,"/models/models.nn"))
save(results.nn, file =paste0(path,"/results/results.nn"))









